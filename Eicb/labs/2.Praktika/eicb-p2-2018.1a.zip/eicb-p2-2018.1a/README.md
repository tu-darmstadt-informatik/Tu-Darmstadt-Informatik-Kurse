# mavlc

`mavlc` is a compiler for the Matrix And Vector Language.

## Prerequisites, setup and usage

Refer to the instructions in `HOWTO.md`.

## License

	Copyright (C) 2016-2018 Embedded Systems and Applications Group
	Department of Computer Science, Technische Universitaet Darmstadt,
	Hochschulstr. 10, 64289 Darmstadt, Germany.
	
	All rights reserved.
	
	This software is provided free for educational use only.
	It may not be used for commercial purposes without the
	prior written permission of the authors.

## Contributors

* Gabriel Eckhardt
* Robin Kruppe
* Sebastian Müller
* Julian Oppermann
* Lukas Sommer
* David Volz
* Lukas Weber
