package ex07;

public class RouteException extends RuntimeException {
    /* implementation not given */
}
