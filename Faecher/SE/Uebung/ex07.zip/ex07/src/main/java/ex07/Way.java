package ex07;

import java.io.Serializable;

public interface Way extends Serializable {

}
