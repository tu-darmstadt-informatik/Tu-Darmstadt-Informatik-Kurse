package ex07;

public class NavigationService {
    static String forWay(Way w) {
        String result = "";
        /* implementation not given */
        return result;
    }

    static String forTurn(Way from, Way to) {
        String result = "";
        /* implementation not given */
        return result;
    }

}
