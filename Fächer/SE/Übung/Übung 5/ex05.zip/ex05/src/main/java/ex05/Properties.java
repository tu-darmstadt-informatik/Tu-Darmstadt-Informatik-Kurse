package ex05;

import javafx.util.Pair;

import java.util.ArrayList;
import java.util.List;

@Concept("Eigenschaft")
public class Properties {

    @Concept("Eigenschaften")
    private List<Pair<String, String>> props = new ArrayList<>();
}
