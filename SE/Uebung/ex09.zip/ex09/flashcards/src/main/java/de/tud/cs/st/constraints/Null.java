package de.tud.cs.st.constraints;

/**
 * Annotates that a parameter or field may be null.
 */
public @interface Null {

}
