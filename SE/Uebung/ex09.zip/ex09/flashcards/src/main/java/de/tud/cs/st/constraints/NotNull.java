package de.tud.cs.st.constraints;

/**
 * Annotates that a parameter or field must never be null.
 */
public @interface NotNull {

}
