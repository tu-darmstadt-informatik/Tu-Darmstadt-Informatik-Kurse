package ex11;

public interface AccountUpdatedListener {
    void accountUpdated(BankAccount bankAccount);
}
