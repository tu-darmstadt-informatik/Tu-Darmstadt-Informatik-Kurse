package ex06;

public class TransferValidator {
    public static void performTransfer(Transfer transfer) {
        Tracer.trace();

        // SOLUTION START
        // TODO: Implement your solution here

        // SOLUTION END

        Tracer.trace();
    }
}
